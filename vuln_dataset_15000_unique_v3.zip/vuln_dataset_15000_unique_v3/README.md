
# Unique & Diverse Vulnerable Dataset (15,000 manifests)

- Guarantees **no duplicate manifests** (package@version sets are unique).
- Adds Python `lxml` (CVE-2021-28957 fixed in 4.6.3) to increase severity diversity.
